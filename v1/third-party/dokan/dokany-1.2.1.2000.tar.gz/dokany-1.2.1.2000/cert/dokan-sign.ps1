$env:CERTISSUER="DokanCA"
$env:ADDITIONALCERT="$pwd\cert\DokanCA.cer"

.\sign.ps1